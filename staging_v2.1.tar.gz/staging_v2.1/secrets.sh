#!/bin/sh
echo $TI_DPLOY_SECRET